"""灰盒原型：单键跳跃跑酷（Jump Runner / greybox v0.5）

运行：  python src\\jump_run.py
自测：  python src\\jump_run.py --selftest 3000      # 无窗口跑 3000 帧，验证机制与生成

设计意图（本轮只验证这些）：
1. 一个键按下去，手感是不是立刻有反馈（蓄力高度 / 二段跳）。
2. 蓄力跳跃（轻点小跳 / 按住高跳）能不能制造“判断距离”的决策。
3. 跑起来的速度爬升有没有把紧张感抬起来。
"""

import json
import math
import os
import random
import sys
import tempfile
import time
import traceback

import pygame

# ---------------------------------------------------------------- 日志（只在出问题时写，平时也留一份）
def _data_dir():
    """frozen（onefile exe）时是 exe 所在目录，源码跑时是 src 目录。"""
    if getattr(sys, "frozen", False):
        return os.path.dirname(os.path.abspath(sys.executable))
    return os.path.dirname(os.path.abspath(__file__))


LOG_PATH = os.path.join(_data_dir(), "run.log")


def log(msg):
    """追加一行到 run.log。写不进去就退到临时目录，日志本身绝不允许把游戏搞崩。"""
    line = f"{time.strftime('%m-%d %H:%M:%S')} {msg}\n"
    for path in (LOG_PATH, os.path.join(tempfile.gettempdir(), "JumpRunner-run.log")):
        try:
            with open(path, "a", encoding="utf-8") as f:
                f.write(line)
            return
        except Exception:
            continue

# ---------------------------------------------------------------- 常量
W, H = 540, 960
FPS = 60
GROUND_Y = 700           # 地面顶面 y
PLAYER_X = 150           # 玩家固定屏幕 x
PW, PH = 36, 52

GRAVITY = 1500.0
JUMP_MIN = 520.0         # 轻点起跳初速
JUMP_MAX = 880.0         # 蓄满起跳初速
AIR_JUMP_V = 560.0       # 二段跳初速
CHARGE_MAX = 0.22        # 蓄力上限（秒）
COYOTE = 0.09            # 郊狼时间：离开地面后仍可起跳
BUFFER = 0.12            # 输入缓冲：落地前按下也算数

BASE_SPEED = 380.0       # 起始横向速度 px/s
SPEED_GAIN = 0.95        # 每米加速
SPEED_CAP = 620.0        # 速度上限

BG = (18, 20, 26)
GROUND_COLOR = (42, 47, 58)
GROUND_EDGE = (58, 66, 82)
PLATFORM_COLOR = (74, 84, 102)
SPIKE_COLOR = (214, 78, 78)
TEXT = (232, 236, 244)
DIM = (128, 138, 156)
ACCENT = (108, 214, 255)

# 配色随距离推进：深夜霓虹 → 紫红黄昏 → 熔金黎明。
# 颜色是“奖励”的一部分：跑得越远，画面越亮，玩家不用看数字也知道自己走深了。
ZONES = [
    {
        "at": 0,
        "sky": ((9, 11, 28), (26, 22, 62), (58, 40, 104)),
        "accent": (110, 220, 255),
        "edge": (96, 190, 255),
        "spike": (255, 120, 92),
        "ground": (38, 43, 58),
    },
    {
        "at": 150,
        "sky": ((26, 12, 44), (86, 28, 78), (176, 62, 86)),
        "accent": (255, 186, 130),
        "edge": (255, 154, 104),
        "spike": (255, 96, 120),
        "ground": (52, 44, 62),
    },
    {
        "at": 300,
        "sky": ((36, 24, 68), (132, 66, 98), (246, 152, 92)),
        "accent": (255, 236, 168),
        "edge": (255, 206, 146),
        "spike": (255, 92, 92),
        "ground": (62, 52, 64),
    },
]

# 关卡表：每关固定种子 → 同一关每次布局一致，玩家能“练会”，而不是每局重新抽签。
# len_m 是终点距离（米）；s0/s1 是本关起止速度；spike/saw 是本块地面放尖刺/锯盘的概率；
# gap 是缺口时间窗；pw 是地面块宽度范围；zone 是这一关的配色位置。
LEVELS = [
    {"name": "霓虹起步", "len_m": 120, "seed": 11, "s0": 380.0, "s1": 440.0, "zone": 0.00,
     "spike": 0.56, "saw": 0.16, "gap": (0.22, 0.30), "pw": (260, 400)},
    {"name": "横越断口", "len_m": 150, "seed": 23, "s0": 420.0, "s1": 490.0, "zone": 0.55,
     "spike": 0.64, "saw": 0.20, "gap": (0.26, 0.34), "pw": (250, 390)},
    {"name": "尖刺地带", "len_m": 170, "seed": 37, "s0": 460.0, "s1": 520.0, "zone": 1.00,
     "spike": 0.80, "saw": 0.26, "gap": (0.24, 0.34), "pw": (270, 410)},
    {"name": "高层步道", "len_m": 190, "seed": 41, "s0": 490.0, "s1": 560.0, "zone": 1.45,
     "spike": 0.74, "saw": 0.26, "gap": (0.27, 0.36), "pw": (260, 400)},
    {"name": "终局疾驰", "len_m": 210, "seed": 53, "s0": 520.0, "s1": 600.0, "zone": 1.90,
     "spike": 0.80, "saw": 0.28, "gap": (0.29, 0.38), "pw": (250, 390)},
]
ENDLESS = {"name": "无尽疾驰", "len_m": 0, "seed": 7, "s0": 380.0, "s1": 620.0, "zone": 0.0,
           "spike": 0.68, "saw": 0.24, "gap": (0.20, 0.36), "pw": (250, 410)}

# 打包成 exe 后 __file__ 落在临时解包目录，最高分要存到 exe 旁边才对。
if getattr(sys, "frozen", False):
    _APP_DIR = os.path.dirname(os.path.abspath(sys.executable))
else:
    _APP_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BEST_PATH = os.path.join(_APP_DIR, "best.json")


def clamp(v, a, b):
    return a if v < a else b if v > b else v


def mix(c1, c2, t):
    t = clamp(t, 0.0, 1.0)
    return tuple(int(a + (b - a) * t) for a, b in zip(c1, c2))


def mix_zone(z1, z2, t):
    out = {"at": z1["at"]}
    for k in ("accent", "edge", "spike", "ground"):
        out[k] = mix(z1[k], z2[k], t)
    out["sky"] = tuple(mix(a, b, t) for a, b in zip(z1["sky"], z2["sky"]))
    return out


def _hash01(n):
    """把序号打散成 0~1 的确定值，用来生成不重复又稳定的剪影轮廓。"""
    n = int(n * 374761393 + 668265263) & 0xFFFFFFFF
    n = ((n ^ (n >> 13)) * 1274126177) & 0xFFFFFFFF
    return ((n ^ (n >> 16)) & 0xFFFF) / 65535.0


class Piece:
    """一块地面。spikes: [(x, w, top, h)]；platform: (x, w, top) 单向平台；
    saw: (中心x偏移, 中心屏幕y, 半径, 巡行半幅, 相位) 往复锯盘。"""
    __slots__ = ("x", "w", "spikes", "platform", "saw")

    def __init__(self, x, w, spikes=None, platform=None, saw=None):
        self.x = x
        self.w = w
        self.spikes = spikes or []
        self.platform = platform
        self.saw = saw


class Game:
    def __init__(self, headless=False):
        self.screen = pygame.display.set_mode((W, H))
        pygame.display.set_caption("单键跳跃跑酷 · 灰盒 v0.5")
        self._set_window_icon()
        self.world = pygame.Surface((W + 40, H))
        self.clock = pygame.time.Clock()
        # 直接用字体文件，绕开 SysFont 在本机枚举字体时的崩溃（中文必须有中文字体）
        self.f_big = self._font(42, bold=True)
        self.f_mid = self._font(24)
        self.f_small = self._font(15)
        self.rng = random.Random(20261121)
        self.headless = headless
        self.best = self._load_best()
        self.skies = [self._build_sky(z["sky"], z["accent"]) for z in ZONES]
        self._sky_cache = {}
        self.vignette = self._build_vignette()
        self.glows = [self._build_glow(z["accent"], 48, 18) for z in ZONES]
        self.level_idx = 0            # 0..4 关卡，5+ 为无尽
        self.attempts = 0             # 本关死亡次数
        self.reset(fresh_level=True)

    # ------------------------------------------------------------ 预渲染
    @staticmethod
    def _build_sky(stops, accent):
        """三段竖直渐变（深空 → 中景 → 地平线）+ 天边那轮霓虹太阳，只算一次。"""
        surf = pygame.Surface((W, H))
        c_top, c_mid, c_bot = stops
        for y in range(H):
            if y <= GROUND_Y:
                t = y / GROUND_Y
                c = mix(c_top, c_mid, t * 1.4) if t < 0.7 else mix(c_mid, c_bot, (t - 0.7) / 0.3)
            else:
                c = c_bot
            pygame.draw.line(surf, c, (0, y), (W, y))

        # 太阳：光晕 + 圆盘。光晕只出现在地平线以上，缺口里不该透出太阳
        cx, cy = W - 150, GROUND_Y - 96
        glow = pygame.Surface((320, 320), pygame.SRCALPHA)
        for r in range(160, 0, -1):
            a = int(14 * (1 - r / 160.0) ** 2)
            pygame.draw.circle(glow, (*accent, a), (160, 160), r)
        surf.blit(glow, (cx - 160, cy - 160), special_flags=pygame.BLEND_ADD)
        # 地平线以下不画天色，改画深不见底的沟壑色：掉下去的缺口要看着“深”，不能看着“亮”
        abyss = mix(c_bot, (0, 0, 0), 0.74)
        pygame.draw.rect(surf, abyss, (0, GROUND_Y - 4, W, H - GROUND_Y + 4))

        sun_c = mix(c_bot, accent, 0.55)
        pygame.draw.circle(surf, sun_c, (cx, cy), 44)
        pygame.draw.circle(surf, mix(sun_c, (255, 255, 255), 0.4), (cx, cy), 44, 2)
        return surf

    @staticmethod
    def _build_vignette():
        """四周压暗的环形渐变，让注意力落在中间跑道上。"""
        surf = pygame.Surface((W, H), pygame.SRCALPHA)
        for k in range(0, 96, 6):
            a = int(78 * (1 - k / 96.0) ** 2)
            pygame.draw.rect(surf, (0, 0, 0, a), (k, k, W - 2 * k, H - 2 * k), width=6)
        return surf

    @staticmethod
    def _build_glow(color, size=96, peak=60):
        """柔光贴图，用于角色/地平线的加法发光。"""
        surf = pygame.Surface((size, size), pygame.SRCALPHA)
        for r in range(size // 2, 0, -1):
            a = int(peak * (1 - r / (size / 2)) ** 2)
            pygame.draw.circle(surf, (*color, a), (size // 2, size // 2), r)
        return surf

    def _palette(self):
        """配色位置：关卡按 zone 定调（关内轻微推进），无尽按距离推进。

        返回 (融合调色, 起始区间下标, 混合比)。
        """
        if self.is_endless():
            z = self.distance() / 150.0
        else:
            prog = 0.0 if not self.goal_x else clamp(self.cam / self.goal_x, 0.0, 1.0)
            z = self.cfg.get("zone", 0.0) + 0.22 * prog
        z = clamp(z, 0.0, len(ZONES) - 1.0 - 1e-6)
        i = int(z)
        t = z - i
        return mix_zone(ZONES[i], ZONES[i + 1], t), i, t

    def _sky_at(self, i, t):
        """两段配色之间的天空，按 10% 步长缓存，避免每帧重画渐变。"""
        key = (i, round(t, 1))
        if key not in self._sky_cache:
            if i + 1 < len(ZONES):
                stops = tuple(mix(a, b, t) for a, b in zip(ZONES[i]["sky"], ZONES[i + 1]["sky"]))
                accent = mix(ZONES[i]["accent"], ZONES[i + 1]["accent"], t)
            else:
                stops, accent = ZONES[i]["sky"], ZONES[i]["accent"]
            self._sky_cache[key] = self._build_sky(stops, accent)
        return self._sky_cache[key]

    # ------------------------------------------------------------ 窗口图标
    @staticmethod
    def _set_window_icon():
        # 打包后资源在临时解包目录里，源码跑时就在 src/assets 旁边
        base = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
        path = os.path.join(base, "assets", "icon.png")
        if not os.path.exists(path):
            return
        try:
            pygame.display.set_icon(pygame.image.load(path))
        except Exception:
            pass

    # ------------------------------------------------------------ 字体
    @staticmethod
    def _font(size, bold=False):
        names = ("msyhbd.ttc", "msyh.ttc", "simhei.ttf", "deng.ttf", "segoeui.ttf", "arial.ttf")
        base = os.path.join(os.environ.get("WINDIR", r"C:\Windows"), "Fonts")
        for n in names:
            p = os.path.join(base, n)
            if os.path.exists(p):
                try:
                    f = pygame.font.Font(p, size)
                    f.set_bold(bold)
                    return f
                except Exception:
                    continue
        return pygame.font.Font(None, size)

    # ------------------------------------------------------------ 存档
    def _load_best(self):
        try:
            with open(BEST_PATH, "r", encoding="utf-8") as f:
                return int(json.load(f).get("best", 0))
        except Exception:
            return 0

    def _save_best(self):
        try:
            with open(BEST_PATH, "w", encoding="utf-8") as f:
                json.dump({"best": self.best}, f, ensure_ascii=False, indent=2)
        except Exception:
            pass

    # ------------------------------------------------------------ 开局
    def _level_cfg(self):
        return LEVELS[self.level_idx] if not self.is_endless() else ENDLESS

    def is_endless(self):
        return self.level_idx >= len(LEVELS)

    def reset(self, fresh_level=False):
        cfg = self._level_cfg()
        self.cfg = cfg
        seed = cfg["seed"] if not self.is_endless() else random.randrange(1, 10 ** 6)
        self.rng = random.Random(seed)
        self.cam = 0.0
        self.y = float(GROUND_Y - PH)
        self.vy = 0.0
        self.grounded = True
        self.airborne_timer = 0.0
        self.air_jumps = 0
        self.jumped = False          # 本轮离地是不是自己跳的：决定郊狼窗口还给不给蓄力
        self.holding = False
        self.charge = 0.0
        self.buffer = 0.0
        self.alive = True
        self.won = False
        self.death_timer = 0.0
        self.win_timer = 0.0
        self.restart_armed = False
        self.level_time = 0.0
        self.saw_phase = 0.0        # 锯盘共用同一个时间相位，布局里只差一个固定偏移
        self.speed = cfg["s0"]
        self.goal_x = None if self.is_endless() else cfg["len_m"] * 100.0
        self.pieces = [Piece(0, 460)]
        self.spawn_x = 460.0
        self.shake = 0.0
        self.particles = []          # [x(世界), y, vx, vy, life, size, color]
        self.trail = []              # 残影：[y, 存在时间]
        self.reason = ""
        self.frames = 0
        self.jump_count = 0
        self.death_snapshot = None
        if fresh_level:
            self.attempts = 0

    # ------------------------------------------------------------ 世界生成
    def _ahead_limit(self):
        return self.cam + W + 700

    def _reach(self):
        """一次满蓄力跳跃的水平可及距离（保守估计）。"""
        airtime = 2 * JUMP_MAX / GRAVITY
        return self.speed * airtime * 0.72

    def _gen(self):
        cfg = self.cfg
        while self.spawn_x < self._ahead_limit():
            # 到终点线就停止生成：终点后面留一小段安全落地区
            if self.goal_x is not None and self.spawn_x > self.goal_x + 520:
                break
            # 缺口按“时间”而非“像素”取，速度涨了缺口同步变宽，难度才不会被速度拉平
            gap = clamp(self.speed * self.rng.uniform(*cfg["gap"]), 85.0, 235.0)
            gap = min(gap, self._reach() * 0.80)
            x = self.spawn_x + gap
            w = self.rng.uniform(*cfg["pw"])
            # 终点门底下必须是实地：接近终点线的那一块直接补长到线后 520px，
            # 保证“冲线前 380px → 线后 520px”是一段连续的、没有任何断口的地
            if self.goal_x is not None and self.spawn_x < self.goal_x:
                if x + w >= self.goal_x - 380.0:
                    w = self.goal_x + 520.0 - x

            # 关卡内的节奏：前 8% 不放障碍（教），之后就按本关概率出（逼）；无尽模式按距离爬升
            if self.goal_x is None:
                prog = clamp(self.cam / 6000.0, 0.0, 1.0)
            else:
                prog = clamp(self.spawn_x / self.goal_x, 0.0, 1.0)
            spike_rate = cfg["spike"] * clamp((prog - 0.06) / 0.22, 0.0, 1.0)
            saw_rate = cfg.get("saw", 0.0) * clamp((prog - 0.10) / 0.26, 0.0, 1.0)
            # 终点前最后 400px 不放障碍，冲线那段必须是干净的
            if self.goal_x is not None and x + w > self.goal_x - 400:
                spike_rate = 0.0
                saw_rate = 0.0

            spikes, platform, saw = [], None, None
            roll = self.rng.random()
            if roll < spike_rate:
                # 高刺（74）必须跳得更高，矮刺（34）只需轻点——两种都得会
                tall = self.rng.random() < 0.45
                sh = 74 if tall else 34
                sw = self.rng.uniform(62.0, 200.0 if tall else 150.0)
                # 钉在块的“崖边”：本来就要在块尾起跳，陷阱顺手一起飞过去，不贴脸
                w = max(w, sw + 560.0)
                sx = w - sw
                spikes = [(sx, sw, GROUND_Y - sh, sh)]
                # 绕行平台：只给一部分刺，剩下的必须正面跳过去
                if self.rng.random() < 0.42:
                    pw_ = sw + 110
                    platform = (sx + sw / 2 - pw_ / 2, pw_, GROUND_Y - 112)
            elif roll < spike_rate + saw_rate:
                # 贴地往复锯：矮（顶在离地 47px），任何一跳都能过；同样守在崖边
                amp = clamp(0.08 * self.speed, 40.0, 55.0)
                w = max(w, 2.0 * amp + 480.0)
                saw = (w - amp, GROUND_Y - 34.0, 23.0, amp, self.rng.uniform(0.0, 6.28))

            self.pieces.append(Piece(x, w, spikes, platform, saw))
            self.spawn_x = x + w

        # 回收离镜头太远的块
        self.pieces = [p for p in self.pieces if p.x + p.w > self.cam - 260]

    # ------------------------------------------------------------ 跳跃
    def _do_jump(self, charge01):
        self.jump_count = getattr(self, "jump_count", 0) + 1
        self.vy = -(JUMP_MIN + (JUMP_MAX - JUMP_MIN) * charge01)
        self.grounded = False
        self.airborne_timer = 0.0
        self.air_jumps = 0
        self.jumped = True
        self.charge = 0.0
        self.holding = False
        self._burst(6, 90)

    def _do_air_jump(self):
        self.vy = -AIR_JUMP_V
        self.air_jumps += 1
        self.buffer = 0.0
        self._burst(5, 60)

    def _burst(self, n, spread, color=None):
        wx = self.cam + PLAYER_X + PW / 2
        if color is None:
            color = self._palette()[0]["accent"]
        for _ in range(n):
            self.particles.append([
                wx + self.rng.uniform(-PW / 2, PW / 2),
                self.y + PH,
                self.rng.uniform(-spread, spread),
                self.rng.uniform(-40, -10),
                self.rng.uniform(0.18, 0.36),
                self.rng.uniform(2, 5),
                color,
            ])

    # ------------------------------------------------------------ 输入事件
    def on_press(self):
        if self.won:
            if self.restart_armed:
                self.next_level()
            return
        if not self.alive:
            if self.restart_armed:
                self.reset()
            return
        if self.grounded or (self.airborne_timer < COYOTE and not self.jumped):
            self.holding = True
            self.charge = 0.0
        else:
            if self.air_jumps < 1:
                self._do_air_jump()
            else:
                self.buffer = BUFFER

    def on_release(self):
        if self.won or not self.alive:
            self.restart_armed = True
            return
        if self.holding:
            self._do_jump(self.charge / CHARGE_MAX)

    def cancel_charge(self):
        """窗口失焦或输入事件丢了：把蓄力作废，别让“按住”状态卡在 True 里出不来。"""
        self.holding = False
        self.charge = 0.0

    def next_level(self):
        """通关后推进：下一关；全部通关后进入无尽模式。"""
        if self.is_endless():
            self.reset(fresh_level=True)      # 无尽模式死了/重开就重来
            return
        self.level_idx += 1
        self.restart_armed = False
        self.reset(fresh_level=True)

    # ------------------------------------------------------------ 物理
    def _player_wx(self):
        return self.cam + PLAYER_X

    def _solids(self):
        """产出实体块：(左, 宽, 顶面 y, 厚度)。地面块一路到底，平台是 12px 厚板。"""
        for p in self.pieces:
            sx = p.x - self.cam
            if sx > W or sx + p.w < -40:
                continue
            yield (sx, p.w, float(GROUND_Y), float(H - GROUND_Y))
            if p.platform:
                px, pw_, ptop = p.platform
                yield (p.x + px - self.cam, pw_, float(ptop), 12.0)

    def _land(self, stop):
        """贴合到 stop 顶面并进入站立状态。"""
        self.y = float(stop) - PH
        self.vy = 0.0
        self.grounded = True
        self.air_jumps = 0
        self.jumped = False
        self.airborne_timer = 0.0
        if self.buffer > 0:
            self.buffer = 0.0
            self._do_jump(0.0)

    def _die(self, reason):
        if not self.alive or self.won:
            return
        self.alive = False
        self.attempts += 1
        self.death_timer = 0.0
        self.shake = 9.0
        self.reason = reason
        self.death_snapshot = {
            "wx": round(self.cam + PLAYER_X, 1),
            "y": round(self.y, 1),
            "vy": round(self.vy, 1),
            "speed": round(self.speed, 1),
            "jumps": self.jump_count,
            "grounded": self.grounded,
            "level": self.level_idx,
            "pieces": [(round(p.x, 1), round(p.w, 1)) for p in self.pieces],
        }
        # 最高分只记无尽模式，关卡模式不掺和进“最佳”
        if self.is_endless():
            dist = self.distance()
            if dist > self.best:
                self.best = dist
                self._save_best()
        self._burst(14, 160)

    def _win(self):
        """到达终点线：冻结世界、记成绩、等玩家按一下进下一关。"""
        if self.won or not self.alive:
            return
        self.won = True
        self.win_timer = 0.0
        self.holding = False
        self.charge = 0.0
        self.x_goal_eta = 0.0
        self.shake = 0.0
        self._burst(22, 220, self._palette()[0]["accent"])

    def distance(self):
        return int(self.cam / 100)

    def update(self, dt):
        self.frames += 1
        if self.won:
            self.win_timer += dt
            self._update_particles(dt)
            self.shake = max(0.0, self.shake - dt * 30)
            return
        if not self.alive:
            self.death_timer += dt
            self._update_particles(dt)
            self.shake = max(0.0, self.shake - dt * 30)
            return

        self.level_time += dt
        self.saw_phase = self.level_time * 4.1888   # 锯盘周期 1.5s
        if self.is_endless():
            self.speed = min(SPEED_CAP, BASE_SPEED + self.distance() * SPEED_GAIN)
        else:
            prog = clamp(self.cam / self.goal_x, 0.0, 1.0)
            self.speed = self.cfg["s0"] + (self.cfg["s1"] - self.cfg["s0"]) * prog
        self.cam += self.speed * dt
        self._gen()

        # 通关判定：人过终点线就算过，不看后面还剩多少地
        if self.goal_x is not None and self.cam + PLAYER_X + PW >= self.goal_x:
            self._win()
            return

        # 蓄力：只有“还没跳出去”的时候才算；起跳后 0.09s 里再按是二段跳，不该继续加高度
        if self.holding and (self.grounded or (self.airborne_timer < COYOTE and not self.jumped)):
            self.charge = min(CHARGE_MAX, self.charge + dt)

        # 重力
        prev_feet = self.y + PH
        self.vy += GRAVITY * dt
        self.y += self.vy * dt
        self.grounded = False

        feet = self.y + PH
        head = self.y
        body_l = PLAYER_X + 4
        body_r = PLAYER_X + PW - 4

        for sx, sw, stop, thick in self._solids():
            if body_r <= sx + 1 or body_l >= sx + sw - 1:
                continue                      # 水平没碰上
            bottom = stop + thick

            if self.vy > 0 and prev_feet <= stop + 1.5 and feet >= stop:
                # 1) 从上方落到顶面
                self._land(stop)
                break
            if thick < 60 and self.vy > 0 and feet > stop and head < bottom:
                # 2) 已经陷进薄板（单向平台）里：贴回顶面，绝不穿过去
                self._land(stop)
                break
            if thick >= 60 and head < bottom - 2 and feet > stop + 2:
                # 3) 身体卡进地面块侧面 → 撞墙
                self._die("crash")
                return

        if self.grounded:
            if self.holding:
                self.charge = min(CHARGE_MAX, self.charge + dt)
            self.airborne_timer = 0.0
        else:
            self.airborne_timer += dt

        if self.buffer > 0:
            self.buffer = max(0.0, self.buffer - dt)

        # 尖刺
        px, py = PLAYER_X, self.y
        for p in self.pieces:
            for sx, sw, stop, sh in p.spikes:
                sx_screen = p.x + sx - self.cam
                if sx_screen + sw < px or sx_screen > px + PW:
                    continue
                if py + PH > stop + 5:
                    self._die("spike")
                    return

        # 往复锯：圆盘贴地来回，碰到就死
        for p in self.pieces:
            if not p.saw:
                continue
            scx, cy, sr, amp, ph = p.saw
            cx = p.x + scx + amp * math.sin(self.saw_phase + ph) - self.cam
            nx = clamp(cx, px, px + PW)
            ny = clamp(cy, py, py + PH)
            if (cx - nx) ** 2 + (cy - ny) ** 2 < sr * sr:
                self._die("saw")
                return

        # 掉出屏幕
        if self.y > H + 40:
            self._die("gap")
            return

        self._update_particles(dt)
        # 残影：跟着角色走，0.18s 内淡出
        self.trail = [[t[0], t[1] + dt] for t in self.trail if t[1] < 0.18]
        self.trail.append([self.y, 0.0])
        self.shake = max(0.0, self.shake - dt * 30)

    def _update_particles(self, dt):
        alive = []
        for p in self.particles:
            p[0] += p[2] * dt
            p[1] += p[3] * dt
            p[3] += 380 * dt
            p[4] -= dt
            if p[4] > 0:
                alive.append(p)
        self.particles = alive

    # ------------------------------------------------------------ 绘制
    def draw(self, surf):
        wob = 0
        if self.shake > 0.1:
            wob = self.rng.uniform(-self.shake, self.shake)
        self._draw_world(self.world)
        surf.fill(BG)
        surf.blit(self.world, (wob, 0))
        self._draw_hud(surf)

    def _draw_world(self, s):
        pal, zi, zt = self._palette()
        s.blit(self._sky_at(zi, zt), (0, 0))

        # 视差剪影：远/中/近三层楼群，颜色由天空色调压暗得到，保证任何配色下都协调
        far = mix(pal["sky"][2], (0, 0, 0), 0.20)
        mid = mix(pal["sky"][2], (0, 0, 0), 0.42)
        near = mix(pal["sky"][2], (0, 0, 0), 0.62)
        for spd, step, base_h, col, win in (
            (0.14, 148, 200, far, False),
            (0.30, 116, 150, mid, False),
            (0.52, 88, 96, near, True),
        ):
            off = (self.cam * spd) % step
            for i in range(-1, int(W / step) + 2):
                x = i * step - off
                h = base_h + _hash01(i * 7 + int(base_h)) * base_h * 0.9
                pygame.draw.rect(s, col, (x, GROUND_Y - h, step - 26, h))
                if win:
                    for k in range(3):
                        wy = GROUND_Y - h + 18 + k * 26
                        if wy < GROUND_Y - 12:
                            pygame.draw.rect(s, pal["accent"], (x + 10, wy, 5, 8))
                            pygame.draw.rect(s, pal["accent"], (x + 28, wy, 5, 8))

        # 高速时的风线
        ratio = (self.speed - BASE_SPEED) / (SPEED_CAP - BASE_SPEED)
        if ratio > 0.3:
            for i in range(9):
                ly = 120 + (_hash01(i * 13) * (GROUND_Y - 200))
                lx = (self.cam * 1.6 + i * 137) % (W + 160) - 160
                ln = 40 + _hash01(i + 3) * 90
                c = mix(pal["sky"][2], pal["accent"], 0.35 * ratio)
                pygame.draw.line(s, c, (lx, ly), (lx + ln, ly), 1)

        # 地面与平台
        g_col, p_col = pal["ground"], mix(pal["ground"], pal["edge"], 0.30)

        # 缺口底部的刺床：掉下去是扎死，不是掉进黑里——先让“深渊”长出牙
        bed_col = mix(pal["spike"], (0, 0, 0), 0.45)
        for i in range(len(self.pieces) - 1):
            a, b = self.pieces[i], self.pieces[i + 1]
            gx0, gx1 = a.x + a.w - self.cam, b.x - self.cam
            if gx1 - gx0 < 40 or gx1 < -40 or gx0 > W + 40:
                continue
            x0 = max(gx0, -40.0)
            x1 = min(gx1, W + 40.0)
            step = 20.0
            k = int((x0) // step)
            while True:
                bx = k * step
                if bx > x1:
                    break
                if bx + step > x0:
                    pygame.draw.polygon(
                        s, bed_col,
                        [(bx, H - 18), (bx + step / 2, H - 62), (bx + step, H - 18)],
                    )
                k += 1
        for p in self.pieces:
            sx = p.x - self.cam
            if sx > W or sx + p.w < -40:
                continue
            pygame.draw.rect(s, g_col, (sx, GROUND_Y, p.w, H - GROUND_Y))
            pygame.draw.rect(s, pal["edge"], (sx, GROUND_Y - 2, p.w, 4))
            pygame.draw.rect(s, mix(pal["edge"], (255, 255, 255), 0.5), (sx, GROUND_Y - 2, p.w, 1))
            # 地面竖纹：跑起来才有“地面在动”的参照物
            stripe = mix(g_col, pal["edge"], 0.16)
            for k in range(int(p.x // 64), int((p.x + p.w) // 64) + 1):
                wx = k * 64 - self.cam
                if -2 < wx < W + 2:
                    pygame.draw.rect(s, stripe, (wx, GROUND_Y + 8, 1, H - GROUND_Y - 8))
            # 断口立面：让“这里要跳”在世界里长出来，而不是靠玩家猜
            pygame.draw.rect(s, mix(pal["edge"], g_col, 0.45), (sx, GROUND_Y, 3, H - GROUND_Y))
            pygame.draw.rect(s, mix(pal["edge"], g_col, 0.45), (sx + p.w - 3, GROUND_Y, 3, H - GROUND_Y))
            if p.platform:
                px, pw_, ptop = p.platform
                px += p.x - self.cam
                pygame.draw.rect(s, p_col, (px, ptop, pw_, 12))
                pygame.draw.rect(s, pal["edge"], (px, ptop, pw_, 3))
                pygame.draw.rect(s, mix(pal["edge"], pal["accent"], 0.5), (px, ptop, 2, 12))
                pygame.draw.rect(s, mix(pal["edge"], pal["accent"], 0.5), (px + pw_ - 2, ptop, 2, 12))
            for sx2, sw, stop, sh in p.spikes:
                bx = p.x + sx2 - self.cam
                n = max(2, int(sw // 30))
                seg = sw / n
                for k in range(n):
                    x0 = bx + k * seg
                    pygame.draw.polygon(
                        s, pal["spike"], [(x0, stop + sh), (x0 + seg / 2, stop), (x0 + seg, stop + sh)]
                    )
                    pygame.draw.polygon(
                        s,
                        mix(pal["spike"], (255, 240, 200), 0.55),
                        [(x0 + seg / 2, stop), (x0 + seg / 2 + 3, stop + sh * 0.45), (x0 + seg / 2 - 3, stop + sh * 0.45)],
                    )
            # 往复锯：一条滑轨 + 转动的齿盘，红得明显，看见就跳
            if p.saw:
                scx, cy, sr, amp, ph = p.saw
                cx = p.x + scx + amp * math.sin(self.saw_phase + ph) - self.cam
                if -70 < cx < W + 70:
                    rail = mix(pal["edge"], g_col, 0.55)
                    pygame.draw.line(s, rail, (p.x + scx - amp - self.cam, cy - sr - 12),
                                     (p.x + scx + amp - self.cam, cy - sr - 12), 2)
                    ang = self.saw_phase * 2.2 + ph
                    pts = []
                    for k in range(16):
                        r = sr if k % 2 == 0 else sr * 0.60
                        a_ = ang + k * math.pi / 8
                        pts.append((cx + math.cos(a_) * r, cy + math.sin(a_) * r))
                    pygame.draw.polygon(s, pal["spike"], pts)
                    pygame.draw.circle(s, mix(pal["spike"], (255, 240, 200), 0.6), (int(cx), int(cy)), 6)
                    pygame.draw.circle(s, mix(pal["sky"][2], (0, 0, 0), 0.8), (int(cx), int(cy)), 3)

        # 终点门：两道立柱 + 顶梁 + 地面棋盘带，远远就能看见“那里就是出口”
        if self.goal_x is not None:
            gx = self.goal_x - self.cam
            if -120 < gx < W + 120:
                col = mix(pal["accent"], (255, 255, 255), 0.25)
                pygame.draw.rect(s, col, (gx - 46, GROUND_Y - 210, 9, 210))
                pygame.draw.rect(s, col, (gx + 37, GROUND_Y - 210, 9, 210))
                pygame.draw.rect(s, col, (gx - 46, GROUND_Y - 219, 92, 9))
                for k in range(6):
                    for row in range(2):
                        if (k + row) % 2 == 0:
                            pygame.draw.rect(
                                s, mix(pal["accent"], (255, 255, 255), 0.5),
                                (gx - 6 + k * 12, GROUND_Y - 4 + row * 10, 12, 10),
                            )
                tag = self.f_small.render("终点", True, col)
                s.blit(tag, tag.get_rect(center=(int(gx), GROUND_Y - 236)))

        # 粒子：颜色自带，随生命淡向天色
        for x, y, _, _, life, size, col in self.particles:
            sx = x - self.cam
            a = clamp(life / 0.36, 0.0, 1.0)
            pygame.draw.rect(s, mix(pal["sky"][2], col, a), (sx, y, size, size))

        # 玩家：残影 + 柔光 + 挤压拉伸 + 蓄力条
        if self.alive or self.death_timer < 1.0:
            for k, (ty, age) in enumerate(self.trail[:-1]):
                a = 1.0 - age / 0.18
                tw = PW * (0.5 + 0.3 * a)
                th = PH * (0.5 + 0.3 * a)
                pygame.draw.rect(
                    s,
                    mix(pal["sky"][2], pal["accent"], 0.15 + 0.4 * a),
                    (PLAYER_X - 10 - k * 7 - (tw - PW) / 2, ty + (PH - th) / 2, tw, th),
                    border_radius=3,
                )
            squash = clamp(1.0 + self.vy / 2600.0, 0.82, 1.18)
            h = PH / squash
            w_ = PW * squash
            rx = PLAYER_X - (w_ - PW) / 2
            ry = self.y + (PH - h)
            if self.alive:
                s.blit(self.glows[zi], (PLAYER_X + PW / 2 - 24, self.y + PH / 2 - 24), special_flags=pygame.BLEND_ADD)
            body = pal["accent"] if self.alive else (200, 110, 110)
            outline = mix(pal["sky"][2], (0, 0, 0), 0.85)
            pygame.draw.rect(s, outline, (rx - 2, ry - 2, w_ + 4, h + 4), border_radius=6)
            pygame.draw.rect(s, body, (rx, ry, w_, h), border_radius=5)
            pygame.draw.rect(s, mix(body, (255, 255, 255), 0.6), (rx + 6, ry + 6, w_ - 12, h * 0.30), border_radius=4)
            # 深色眼睛压在亮色身体上，任何配色下都能读出“朝向”
            pygame.draw.circle(s, outline, (int(rx + w_ - 10), int(ry + 20)), 4)
            if self.charge > 0:
                pygame.draw.rect(s, mix(pal["sky"][2], (0, 0, 0), 0.35), (PLAYER_X - 5, self.y - 16, 46, 7), border_radius=3)
                pygame.draw.rect(s, pal["accent"], (PLAYER_X - 5, self.y - 16, 46 * (self.charge / CHARGE_MAX), 7), border_radius=3)

        s.blit(self.vignette, (0, 0))

    def _draw_hud(self, s):
        pal, zi, _ = self._palette()
        dist = self.distance()

        if self.is_endless():
            head = "无尽疾驰"
            right = f"最佳 {self.best} m"
            self._bar(s, pal, dist, None)
        else:
            cfg = self.cfg
            head = f"第 {self.level_idx + 1}/{len(LEVELS)} 关 · {cfg['name']}"
            remain = max(0, cfg["len_m"] - dist)
            right = f"剩余 {remain} m · 死亡 {self.attempts}"
            self._bar(s, pal, dist, cfg["len_m"])

        shadow = self.f_mid.render(head, True, (0, 0, 0))
        s.blit(shadow, (28, 30))
        s.blit(self.f_mid.render(head, True, TEXT), (26, 28))
        s.blit(self.f_small.render(right, True, mix(pal["accent"], TEXT, 0.55)), (28, 66))

        shadow2 = self.f_big.render(f"{dist} m", True, (0, 0, 0))
        s.blit(shadow2, (28, 96))
        s.blit(self.f_big.render(f"{dist} m", True, TEXT), (26, 94))

        if not self.alive:
            self._panel(s, pal, f"{dist} m", {"spike": "撞尖刺", "saw": "撞上锯盘", "crash": "撞上侧面", "gap": "掉进缺口"}.get(self.reason, "结束"),
                        "按空格 / 点击 重来本关（先松开键）", pal["spike"])
        elif self.won:
            nxt = "进入无尽模式" if self.level_idx + 1 >= len(LEVELS) else f"进入第 {self.level_idx + 2} 关"
            self._panel(s, pal, "通关", f"{self.cfg['name']} · {self.level_time:.1f}s · 死亡 {self.attempts}",
                        f"按空格 / 点击 {nxt}", pal["accent"])

    def _bar(self, s, pal, dist, goal):
        """关卡进度条；无尽模式退化成速度条。"""
        x0, y0, w0, h0 = 28, 150, 190, 8
        pygame.draw.rect(s, mix(pal["sky"][2], (0, 0, 0), 0.3), (x0, y0, w0, h0), border_radius=4)
        if goal:
            prog = clamp(dist / goal, 0, 1)
            pygame.draw.rect(s, pal["accent"], (x0, y0, w0 * prog, h0), border_radius=4)
            pygame.draw.rect(s, mix(pal["accent"], (255, 255, 255), 0.7), (x0 + w0 - 2, y0 - 3, 2, h0 + 6))
            s.blit(self.f_small.render("进度", True, DIM), (x0 + w0 + 8, y0 - 6))
        else:
            ratio = clamp((self.speed - BASE_SPEED) / (SPEED_CAP - BASE_SPEED), 0, 1)
            pygame.draw.rect(s, pal["accent"], (x0, y0, w0 * ratio, h0), border_radius=4)
            s.blit(self.f_small.render("速度", True, DIM), (x0 + w0 + 8, y0 - 6))

    def _panel(self, s, pal, title, subtitle, hint, accent):
        shade = pygame.Surface((W, H), pygame.SRCALPHA)
        shade.fill((6, 6, 14, 185))
        s.blit(shade, (0, 0))
        panel = pygame.Surface((400, 200), pygame.SRCALPHA)
        pygame.draw.rect(panel, (*mix(pal["sky"][1], (0, 0, 0), 0.4), 214), (0, 0, 400, 200), border_radius=16)
        pygame.draw.rect(panel, accent, (0, 0, 400, 200), 2, border_radius=16)
        s.blit(panel, (W / 2 - 200, H / 2 - 124))
        t1 = self.f_big.render(title, True, TEXT)
        t2 = self.f_mid.render(subtitle, True, accent)
        hint_s = self.f_small.render(hint, True, mix(TEXT, DIM, 0.45))
        s.blit(t1, t1.get_rect(center=(W / 2, H / 2 - 64)))
        s.blit(t2, t2.get_rect(center=(W / 2, H / 2 - 6)))
        s.blit(hint_s, hint_s.get_rect(center=(W / 2, H / 2 + 46)))


# ---------------------------------------------------------------- 自动驾驶（自测用）
def _hazard_span(p):
    """这一块地面里最早出现的危险区间 (左, 右)，没有就返回 None。"""
    span = None
    for sx, sw, stop, sh in p.spikes:
        s = (p.x + sx, p.x + sx + sw)
        span = s if span is None or s[0] < span[0] else span
    if p.saw:
        scx, cy, sr, amp, ph = p.saw
        s = (p.x + scx - amp, p.x + scx + amp)
        span = s if span is None or s[0] < span[0] else span
    return span


def autopilot(g, dt):
    """粗糙 AI：先定“松手点”，再按需要的高度反算蓄力。

    - 松手点 = 陷阱左沿前 90px，或者块尾缺口前 40px
    - 蓄力取两个下限的较大值：落在陷阱之后 / 在陷阱高度以上的滞空够长
    它不代表玩家水平，只用来证明地形本身没有不可解的地方。
    """
    if g.won:
        g.on_release()
        g.on_press()
        return
    if not g.alive:
        g.on_release()   # 松开后即可重开
        g.on_press()
        return

    px_left = g.cam + PLAYER_X
    px_right = px_left + PW
    speed = max(g.speed, 1.0)

    if g.holding:
        if g.charge >= getattr(g, "_ap_t", 0.0) or g.charge >= CHARGE_MAX:
            g.on_release()
        return

    if not g.grounded:
        return   # 不做空中二段跳，让自测算的是“地面起跳”的公平性

    idx = -1
    cur = None
    for i, p in enumerate(g.pieces):
        if p.x <= px_left < p.x + p.w:
            cur, idx = p, i
            break
    if cur is None:
        return
    nxt = g.pieces[idx + 1] if idx + 1 < len(g.pieces) else None

    hz = _hazard_span(cur)
    # 松手点：有崖边陷阱 → 陷阱左沿前 120px；没有 → 块尾前 40px
    if hz is not None and hz[0] > px_right + 60.0:
        release_x = hz[0] - 120.0
    else:
        hz = None
        release_x = cur.x + cur.w - 40.0

    target = (nxt.x + 100.0) if nxt is not None else (cur.x + cur.w + 520.0)
    v = (target - release_x) * GRAVITY / (2.0 * speed)
    if hz is not None:
        width = hz[1] - hz[0]
        h = 0.0
        for sx, sw, stop, sh in cur.spikes:
            h = max(h, float(sh))
        t_need = (width + 200.0) / speed
        v = max(v, math.sqrt((GRAVITY * t_need / 2.0) ** 2 + 2.0 * GRAVITY * h))
        # 到陷阱左沿时必须已经高过 h：不够就把起跳速度往上加
        gap = max(hz[0] - release_x, 1.0)
        while v < JUMP_MAX:
            disc = max(v * v - 2.0 * GRAVITY * h, 1.0)
            if speed * ((v - math.sqrt(disc)) / GRAVITY) <= gap:
                break
            v += 20.0
    v = clamp(v, JUMP_MIN, JUMP_MAX)

    charge = (v - JUMP_MIN) / (JUMP_MAX - JUMP_MIN) * CHARGE_MAX
    if release_x - px_right <= speed * charge + 8.0:
        g._ap_t = charge if release_x > px_right else 0.02
        g.on_press()


def main():
    selftest = "--selftest" in sys.argv
    frames_limit = 3000
    for i, a in enumerate(sys.argv):
        if a == "--selftest" and i + 1 < len(sys.argv):
            frames_limit = int(sys.argv[i + 1])

    if selftest:
        os.environ["SDL_VIDEODRIVER"] = "dummy"

    pygame.init()
    g = Game(headless=selftest)
    dt = 1.0 / FPS

    if selftest:
        deaths = 0
        clears = 0
        reasons = {}
        death_log = []
        clear_log = []
        max_speed = 0.0
        was_alive = True
        was_won = False
        first_snapshot = None
        for i in range(frames_limit):
            autopilot(g, dt)
            g.update(dt)
            if g.won and not was_won:
                clears += 1
                clear_log.append((g.level_idx + 1, round(g.level_time, 1), g.attempts))
            if was_alive and not g.alive:
                deaths += 1
                if first_snapshot is None:
                    first_snapshot = g.death_snapshot
                reasons[g.reason] = reasons.get(g.reason, 0) + 1
                if len(death_log) < 12:
                    death_log.append((g.level_idx + 1, g.distance(), g.reason))
            was_alive = g.alive
            was_won = g.won
            max_speed = max(max_speed, g.speed)
            if i % 600 == 0:
                g.draw(g.world)
        print(f"[selftest] frames={frames_limit} 当前关={g.level_idx + 1} 通关次数={clears} 死亡={deaths} "
              f"原因={reasons} 最高速度={max_speed:.0f}px/s")
        print(f"[selftest] 通关记录(关,用时s,死亡数)={clear_log}")
        print(f"[selftest] 死亡记录(关,距离,原因)={death_log}")
        print(f"[selftest] 首帧死亡快照={first_snapshot}")
        print("[selftest] OK：跳跃/落地/尖刺/缺口/生成/通关/重开 全部跑通")
        pygame.quit()
        return

    running = True
    prev_down = False
    focus_lost = getattr(pygame, "WINDOWFOCUSLOST", None)
    exit_reason = "loop-ended"
    was_alive = True
    hb = 0.0
    log(f"启动 pid={os.getpid()} frozen={getattr(sys, 'frozen', False)} py={sys.version.split()[0]}")
    try:
        while running:
            dt = min(g.clock.tick(FPS) / 1000.0, 0.05)
            for e in pygame.event.get():
                if e.type == pygame.QUIT:
                    exit_reason = "quit-event"
                    running = False
                elif e.type == pygame.KEYDOWN and e.key in (pygame.K_ESCAPE,):
                    exit_reason = f"esc-key(scan={getattr(e, 'scancode', '?')})"
                    running = False
                elif focus_lost is not None and e.type == focus_lost:
                    # 切出去时键还按着，keyup 收不到 → 蓄力会一直卡着，这里直接作废
                    g.cancel_charge()
                    prev_down = False
                    log("焦点丢失，蓄力已作废")
            # 每帧自己采样按键状态，不信 KEYDOWN/KEYUP 事件：事件会丢、会自动重复
            keys = pygame.key.get_pressed()
            down = bool(
                pygame.mouse.get_pressed()[0]
                or keys[pygame.K_SPACE]
                or keys[pygame.K_UP]
                or keys[pygame.K_w]
            )
            if down and not prev_down:
                g.on_press()
            elif prev_down and not down:
                g.on_release()
            prev_down = down

            was_alive = g.alive
            g.update(dt)
            if was_alive and not g.alive and not g.won:
                log(f"死亡 第{g.level_idx + 1}关 距离{g.distance()}m 原因={g.reason}")
            elif was_alive and g.won:
                log(f"过关 第{g.level_idx + 1}关 用时{g.level_time:.1f}s")

            hb += dt
            if hb >= 5.0:
                hb = 0.0
                log(f"心跳 第{g.level_idx + 1}关 alive={g.alive} 距离{g.distance()}m "
                    f"fps={g.clock.get_fps():.0f}")

            g.draw(g.screen)
            pygame.display.flip()
    except BaseException:
        log("崩溃：\n" + traceback.format_exc())
        raise
    finally:
        log(f"退出 reason={exit_reason}")
        try:
            pygame.quit()
        except Exception:
            pass


if __name__ == "__main__":
    main()










