"""碰撞回归测试：专治“穿墙”。

跑法：python tests\\probe_collision.py
每条断言失败就直接报错，不静默。
"""

import os
import sys

os.environ["SDL_VIDEODRIVER"] = "dummy"
sys.path.insert(
    0,
    os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "src"),
)

import pygame  # noqa: E402

from jump_run import GROUND_Y, PH, PLAYER_X, PW, FPS, Game, Piece  # noqa: E402

DT = 1.0 / FPS
PLAT_TOP = 590.0


def new_game(piece):
    pygame.init()
    g = Game(headless=True)
    g.pieces = [piece]
    g.spawn_x = piece.x + piece.w
    g.cam = 0.0
    return g


def step(g, frames, freeze=True):
    for _ in range(frames):
        g.update(DT)
        if freeze:
            g.cam = 0.0          # 冻结世界，专注测垂直碰撞


def case_jump_through_platform():
    """从下往上穿过薄平台后，落下来必须停在平台顶面，不能穿下去。"""
    g = new_game(Piece(0, 1600, platform=(60, 240, PLAT_TOP)))
    g.y = PLAT_TOP + 30.0        # 头在平台板下方
    g.vy = -700.0                # 向上冲，会穿过 12px 的薄板
    step(g, 120)
    assert g.alive, "不该死"
    assert abs(g.y - (PLAT_TOP - PH)) < 1.0, f"应停在平台顶面 y={PLAT_TOP - PH}，实际 {g.y}"
    assert g.grounded, "应处于站立状态"
    return "上升穿过 → 下落贴回平台顶面"


def case_inside_slab_snap():
    """身体已经在薄板内部（下落中）时，要贴回顶面而不是漏下去。"""
    g = new_game(Piece(0, 1600, platform=(60, 240, PLAT_TOP)))
    g.y = PLAT_TOP - 20.0        # 身体跨在板子里
    g.vy = 380.0
    step(g, 3)
    assert abs(g.y - (PLAT_TOP - PH)) < 1.0, f"陷进板子应贴回顶面，实际 y={g.y}"
    return "陷进薄板 → 贴回顶面"


def case_side_crash():
    """身体卡进地面块侧面 → 撞墙，而不是继续穿过去。"""
    g = new_game(Piece(0, 1200))
    g.y = GROUND_Y + 20.0        # 身体已在地面块内部
    g.vy = 300.0
    step(g, 2, freeze=False)
    assert not g.alive, "应判定撞墙"
    assert g.reason == "crash", f"死因应为 crash，实际 {g.reason}"
    return "陷进地面块 → 撞墙判死"


def case_run_on_ground():
    """站在地面上正常跑，不该被误判撞墙或卡住。"""
    g = new_game(Piece(0, 4000))
    g.y = GROUND_Y - PH
    g.vy = 0.0
    step(g, 240, freeze=False)
    assert g.alive, f"正常跑步不该死，死因={g.reason}"
    assert g.grounded, "应一直贴着地面"
    return "平跑 240 帧无异常"


if __name__ == "__main__":
    cases = [
        case_jump_through_platform,
        case_inside_slab_snap,
        case_side_crash,
        case_run_on_ground,
    ]
    for c in cases:
        print(f"[PASS] {c.__name__}: {c()}")
    print(f"[OK] {len(cases)} 项碰撞回归全部通过")
