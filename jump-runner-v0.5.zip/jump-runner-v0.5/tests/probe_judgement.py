"""判定回归：专查“按键下去以后判定卡住 / 被吃”的几种情况。

跑法： python tests/probe_judgement.py

这几条以前都是真踩过的坑：
1. 起跳后 0.09s 内再按一下，被当成“还在地上蓄力”——按住不放能二次加高度，二段跳反而没了。
2. 切出窗口时键还按着，keyup 收不到，蓄力条卡在满格。
3. 撞死那一秒手指还按着，“按空格重来”按了没反应。
4. 郊狼窗口（自己走下平台）必须还能起跳，别被第 1 条的修法误伤。
"""

import os
import sys

os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(HERE), "src"))

import pygame  # noqa: E402

import jump_run as jr  # noqa: E402

results = []


def check(name, ok, detail=""):
    results.append((name, bool(ok), detail))


def fresh():
    return jr.Game(headless=True)


def test_double_tap_is_air_jump():
    g = fresh()
    g.on_press()
    g.update(1.0 / 60)
    g.on_release()
    jumped_vy = g.vy
    check("地面起跳真的离地了", g.jumped and not g.grounded, f"vy={jumped_vy:.0f}")

    g.on_press()
    check("起跳后再按不进蓄力", g.holding is False, f"holding={g.holding}")
    check("起跳后再按立刻算二段跳", g.air_jumps == 1, f"air_jumps={g.air_jumps}")
    check("二段跳速度按 AIR_JUMP_V 给", abs(g.vy + jr.AIR_JUMP_V) < 1e-6, f"vy={g.vy:.1f}")

    # 按住一段时间再松手：松手不能再去改速度（旧代码这里会把 vy 重算成蓄力跳）
    before = g.vy
    g.update(0.06)
    vy_before_release = g.vy
    g.on_release()
    check("松手不再覆盖空中速度", abs(g.vy - vy_before_release) < 1e-9, f"{before:.0f}->{g.vy:.0f}")
    check("空中不会继续蓄力加高度", g.charge == 0.0, f"charge={g.charge}")


def test_focus_loss_clears_charge():
    g = fresh()
    g.on_press()
    g.update(1.0 / 60)
    check("按下后进入蓄力", g.holding and g.charge > 0, f"charge={g.charge:.3f}")
    g.cancel_charge()
    check("失焦后蓄力被作废", (not g.holding) and g.charge == 0.0, f"holding={g.holding} charge={g.charge}")


def test_restart_after_death_needs_release():
    g = fresh()
    g.on_press()
    g.update(1.0 / 60)
    g._die("spike")
    check("按住时死亡", g.alive is False, f"alive={g.alive}")

    g.on_press()  # 手指一直按着，没有新的按下边沿
    check("按着不放不会自动重开", g.alive is False and g.restart_armed is False,
          f"alive={g.alive} armed={g.restart_armed}")

    g.on_release()
    check("松开后重来就绪", g.restart_armed is True, f"armed={g.restart_armed}")

    g.on_press()
    check("再按一下确实重开了", g.alive and g.cam == 0.0, f"alive={g.alive} cam={g.cam}")


def test_coyote_still_works():
    g = fresh()
    # 模拟“自己走下平台”：不是跳出去的，离地 0.05s
    g.grounded = False
    g.jumped = False
    g.airborne_timer = 0.05
    g.on_press()
    check("郊狼窗口还能起跳", g.holding is True, f"holding={g.holding}")

    g2 = fresh()
    g2.grounded = False
    g2.jumped = False
    g2.airborne_timer = jr.COYOTE + 0.02
    g2.on_press()
    check("超出郊狼窗口就按不出跳", g2.holding is False and g2.air_jumps == 1,
          f"holding={g2.holding} air_jumps={g2.air_jumps}")


def main():
    pygame.init()
    test_double_tap_is_air_jump()
    test_focus_loss_clears_charge()
    test_restart_after_death_needs_release()
    test_coyote_still_works()
    pygame.quit()

    bad = 0
    for name, ok, detail in results:
        print(("  ok   " if ok else "  FAIL ") + name + (f"   ({detail})" if detail else ""))
        bad += 0 if ok else 1
    print(f"[probe_judgement] {len(results) - bad}/{len(results)} 通过")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
