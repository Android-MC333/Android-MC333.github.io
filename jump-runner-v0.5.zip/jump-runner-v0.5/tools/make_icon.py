"""生成 Jump Runner 的图标：暗底 + 米色方块 + 贴地红刺 + 一条地面线。

不用现成素材，全部按比例画，各尺寸单独渲染（小尺寸不会被插值糊掉）。
输出：src/assets/icon.png（256）与 src/icon.ico（多尺寸）。

跑法：python tools/make_icon.py
"""

import io
import os
import struct

from PIL import Image, ImageDraw

BG = (11, 13, 20)
GROUND = (43, 49, 64)
PLAYER = (242, 232, 203)
SPIKE = (217, 79, 79)

SIZES = [16, 20, 24, 32, 40, 48, 64, 128, 256]


def render(size):
    img = Image.new("RGB", (size, size), BG)
    d = ImageDraw.Draw(img)

    # 地面线：底边往上留一点空
    gy = round(size * 0.80)
    gh = max(1, round(size * 0.055))
    d.rectangle([round(size * 0.06), gy, round(size * 0.94), gy + gh - 1], fill=GROUND)

    # 玩家：米色方块。大尺寸画成离地起跳的那一下，小尺寸贴地免得糊成一团
    px0 = round(size * 0.19)
    px1 = round(size * 0.51)
    lift = round(size * 0.10) if size >= 32 else max(1, round(size * 0.015))
    ph = round(size * 0.32)
    d.rectangle([px0, gy - lift - ph, px1, gy - lift - 1], fill=PLAYER)

    # 尖刺：三个贴地的小三角，右侧一列
    n = 3 if size >= 32 else 2
    sx0 = size * 0.60
    sx1 = size * 0.93
    sh = max(2, round(size * 0.15))
    step = (sx1 - sx0) / n
    for i in range(n):
        left = sx0 + step * i
        d.polygon(
            [
                (round(left), gy - 1),
                (round(left + step * 0.78), gy - 1),
                (round(left + step * 0.39), gy - sh),
            ],
            fill=SPIKE,
        )
    return img


def make_ico(images, path):
    """PNG-in-ICO，每个尺寸独立绘制，不让系统去缩放。"""
    payloads = []
    for img in images:
        buf = io.BytesIO()
        img.save(buf, format="PNG", optimize=True)
        payloads.append(buf.getvalue())

    header = struct.pack("<HHH", 0, 1, len(images))
    offset = 6 + 16 * len(images)
    entries = b""
    for img, data in zip(images, payloads):
        w = 0 if img.width >= 256 else img.width
        entries += struct.pack(
            "<BBBBHHII", w, w, 0, 0, 1, 32, len(data), offset
        )
        offset += len(data)
    with open(path, "wb") as f:
        f.write(header + entries + b"".join(payloads))


def main():
    here = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    assets = os.path.join(here, "src", "assets")
    os.makedirs(assets, exist_ok=True)

    big = render(256)
    big.save(os.path.join(assets, "icon.png"), optimize=True)
    make_ico([render(s) for s in SIZES], os.path.join(here, "src", "icon.ico"))
    print("icon.png ->", os.path.join(assets, "icon.png"))
    print("icon.ico ->", os.path.join(here, "src", "icon.ico"))


if __name__ == "__main__":
    main()
